app.controller('statCtrl', function($scope, $rootScope){

    const { serverUrl, penznem } = $rootScope;
   
    $scope.getStatistics = function(){
        axios.get().then(res =>{
            res.data.forEach(element => {
                $scope.events.push(
                    {
                        felhasznalok:,
                        javitasok:,
                        szerelok:,
                        tipusok:,
                        tulajdonos:

                    }
                )
            });
        })
    }

    $scope.getStatistics();

    $rootScope.$on("updateStatistics", function(){
        $scope.getStatistics();
     });
});